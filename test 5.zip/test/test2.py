import math
def create_array(l):
    return [math.sin(2*q)/2+math.cos(q)/5 for q in range(l)]
m=create_array(10)
def put_array(a):
    for q,w in enumerate(a):
        print(f'''lst[{q}]={w:6.3f}''')
put_array(m)
def count_positive_with_even_indexes(m):
    count_of_positive_with_even_indexes=0
    for q in range(len(m)):
        if q%2==0 and m[q]>0:
            count_of_positive_with_even_indexes+=1
    print('count of positive with even indexes',count_of_positive_with_even_indexes)
count_positive_with_even_indexes(m)
