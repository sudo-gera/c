def create_list(a,n):
    import random
    return [random.randint(-a,a) for w in range(n)]
def write_list(l):
    if any([type(q)==list for q in l]):
        for q in l:
            if type(q)==list:
                print(*q,sep='\t')
            else:
                print(q)
    else:
        print(*l,sep='\t')
def create_matrix(a,n,m):
    return [create_list(a,m) for q in range(n)]
q=create_matrix(9,9,9)
write_list(q)
def max_in_each_column(q):
    import itertools
    return list(map(max,itertools.zip_longest(*q,fillvalue=float('-inf'))))
print()
write_list(max_in_each_column(q))
