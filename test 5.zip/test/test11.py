def fill():
    return [[100-10*q-e for e in range(10)] for q in range(10)]
for q in fill():
    print(*q,sep='\t')
