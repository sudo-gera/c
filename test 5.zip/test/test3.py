def count_elements(l):
    d={}
    for q in l:
        d[q]=0
    for q in l:
        d[q]+=1
    return d
def read_list(t):
    return [t(q) for q in input().split()]
l=read_list(int)
d=count_elements(l)
def print_counts(d):
    for q,w in d.items():
        print(f'''{q:8}    |{w:8}''')
print_counts(d)
