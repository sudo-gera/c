def create_list(a,n):
    import random
    return [random.randint(-a,a) for w in range(n)]
def write_list(l):
    print(*l,sep='\t')
n=int(input())
if n<0:
    print('wrong input')
else:
    d=create_list(9,n)
    p=create_list(9,n)
    write_list(d)
    write_list(p)
    def half_max(d,p):
        c=[max(q,w)/2 for q,w in zip(d,p)]
        return c
    c=half_max(d,p)
    write_list(c)
