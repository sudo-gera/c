def write_list(l):
    print(*l,sep='\t')
def read_list(t):
    return [t(q) for q in input().split()]
l=read_list(int)
def only_extremums(l):
    return [w for q,w,e in zip(l,l[1:],l[2:]) if q<w>e or q>w<e]
a=only_extremums(l)
write_list(a)
