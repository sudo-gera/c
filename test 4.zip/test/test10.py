def read_list(t):
    return [t(q) for q in input().split()]
a=read_list(int)
def put_negative_with_odd_indexes(a):
    for q,w in enumerate(a):
        if q%2 and w<0:
            print(f'''list_1[{q}]={w:2}''')
put_negative_with_odd_indexes(a)
