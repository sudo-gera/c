s=input()
def get_first(s):
    s=s.replace('/','|').replace('\\','|').split('|')
    if len(s)<2:
        print('wrong input')
    else:
        s=s[1]
    return s
print(get_first(s))
