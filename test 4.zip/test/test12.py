def create_list(a,n):
    import random
    return [random.randint(-a,a) for w in range(n)]
def write_list(l):
    if any([type(q)==list for q in l]):
        for q in l:
            if type(q)==list:
                print(*q,sep='\t')
            else:
                print(q)
    else:
        print(*l,sep='\t')
def create_matrix(a,n,m):
    return [create_list(a,m) for q in range(n)]
q=create_matrix(9,9,9)
write_list(q)
print()
def sort_decreasing_increasing(q):
    for w,e in enumerate(q):
        e.sort(reverse=(w%2==0))
sort_decreasing_increasing(q)
write_list(q)
