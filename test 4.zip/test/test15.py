types = (int,bool,str)
values = (0,'+',3,'-',True)
def type_sort(t,v):
    for q in t:
        for w in v:
            if type(w)==q:
                print(w,end=' ')
        print()
type_sort(types,values)
