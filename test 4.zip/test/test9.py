def write_list(l):
    print(*l,sep='\t')
def read_list(t):
    return [t(q) for q in input().split()]
a=read_list(str)
def sort_by_length_and_rev_lex(a):
    a.sort(key=lambda s:[len(s),[-ord(q) for q in s]])
sort_by_length_and_rev_lex(a)
write_list(a)
