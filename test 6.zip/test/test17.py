def create_list(a,b,n,k):
    import random
    return [
        sum([
            random.randint(a,b)
        for q in range(k)])
    for w in range(n)]
import prettytable
import random
p=prettytable.PrettyTable()
p.field_names=['№','n','k','Список','Отклонение','ср. ар','Макс','Мнн','Сравнение']
num=int(input())
for q in range(num):
    n=random.randint(1,num)
    k=random.randint(1,num)
    l=create_list(0,100,n,k)
    av=round(sum(l)/len(l),2)
    d=[round(q-av,2) for q in l]
    max_=max(l)
    min_=min(l)
    cmp=abs((max_+min_)/2-av)<1
    p.add_row([q+1,n,k,l,d,av,max_,min_,cmp])
print(p)

