def write_list(l):
    if any([type(q)==list for q in l]):
        for q in l:
            if type(q)==list:
                print(*q,sep='\t')
            else:
                print(q)
    else:
        print(*l,sep='\t')
def create_table():
    import random
    return [
        [random.randint(-1,1),random.randint(-1,1),random.randint(-1,1),],
        [random.randint(-1,1),random.randint(-1,1),random.randint(-1,1),],
        [random.randint(-1,1),random.randint(-1,1),random.randint(-1,1),],
    ]
def check_if_first_wins(t):
    for q in t+list(zip(*t))+[
        [t[0][0],t[1][1],t[2][2]],
        [t[0][2],t[1][1],t[2][0]],
    ]:
        if set(q)=={1}:
            return True
    return False
t=create_table()
write_list(t)
print(check_if_first_wins(t))


