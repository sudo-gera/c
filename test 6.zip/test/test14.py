def create_list(a,n):
    import random
    return [random.randint(-a,a) for w in range(n)]
def create_matrix(a,n,m):
    return [create_list(a,m) for q in range(n)]
def write_list(l):
    if any([type(q)==list for q in l]):
        for q in l:
            if type(q)==list:
                print(*q,sep='\t')
            else:
                print(q)
    else:
        print(*l,sep='\t')
m=int(input())
n=int(input())
q=create_matrix(9,m,n)
def swap_min_max(m):
    s=sum([[[s,q,a] for a,s in enumerate(w)] for q,w in enumerate(m)],[])
    a=max(s)
    d=min(s)
    m[a[1]][a[2]],m[d[1]][d[2]]=m[d[1]][d[2]],m[a[1]][a[2]]
write_list(q)
print()
swap_min_max(q)
write_list(q)
