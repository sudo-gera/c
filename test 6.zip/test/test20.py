check = [[10, 5, 20, 2, 8],[10, 10, 8],[20, 5, 20, 8]]
summa_check=0
def discount():
    import random
    disc = round(random.random(),2)
    print(f'Cкидка по чеку =',disc)
    return disc

def summa(check_index):
    global summa_check
    c=check[check_index]
    print(f'{check_index+1} чек - {c}. ',end='')
    disc=discount()
    s=sum(c)
    n=round(s-s*disc,2)
    print(f'Сумма чека без скидки {s}, со скидкой {n}')
    summa_check+=n


summa(0)
summa(1)
summa(2)
print('Сумма покупки',round(summa_check,2))
