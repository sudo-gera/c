def write_list(l):
    if any([type(q)==list for q in l]):
        for q in l:
            if type(q)==list:
                print(*q,sep='\t')
            else:
                print(q)
    else:
        print(*l,sep='\t')
def create_list(a,n):
    import random
    return [random.randint(-a,a) for w in range(n)]
def count_elements(l):
    d={}
    for q in l:
        d[q]=0
    for q in l:
        d[q]+=1
    return d
l=create_list(9,9)
write_list(l)
def select_not_twice_repeated(l):
    d=count_elements(l)
    l=[q for q in l if d[q]!=2]
    return l
l=select_not_twice_repeated(l)
write_list(l)
