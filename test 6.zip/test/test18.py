a=['привет', 'добрый день', 'hello', 'доброе утро', 'добрый вечер', 'здравствуйте']
s=['good bye', 'bye bye', 'до свидания', 'пока']
def reply(msg,l):
    import random
    if any([q in msg.lower() for q in l]):
        print(random.choice(l))
        return True
    return False

while 1:
    print('Привет! я понимаю приветствия:')
    print('    '+' '.join(a))
    print('я понимаю прощания:')
    print('    '+' '.join(s))
    print('введите `\\exit, чтобы закончить')
    print()
    d=input()
    if d=='\\exit':
        break
    print()
    if not reply(d,a) and not reply(d,s):
        print('я не понял')
    print()
