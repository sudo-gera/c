def cast():
    s=input()
    print(bool(s))
    try:
        print(int(s))
    except Exception:
        print('int failed')
    try:
        print(float(s))
    except Exception:
        print('float failed')
    print(list(s))
    print(tuple(s))
cast()
