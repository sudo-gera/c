def write_list(l):
    print(*l,sep='\t')
# a
a=map(int,input().split())
# b
a=map(lambda q:0 if q[0]%2 else -1,enumerate(a))
# c
write_list(a)
